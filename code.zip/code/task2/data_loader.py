import pandas as pd

def load_data(data_dir):
    train_meta = pd.read_csv(f"{data_dir}/train_metadata.csv")
    test_meta = pd.read_csv(f"{data_dir}/test_metadata.csv")

    X_paths = train_meta["image_path"]
    y = train_meta["class_id"]

    X_test_paths = test_meta["image_path"]
    return X_paths, X_test_paths, y