import numpy as np
import pandas as pd
import torch
import torchvision.transforms as transforms
import torchvision.models as models
import matplotlib.pyplot as plt

from PIL import Image
from tqdm import tqdm

from sklearn.model_selection import (train_test_split, cross_val_score)
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
from sklearn.ensemble import (HistGradientBoostingClassifier, VotingClassifier)
from sklearn.metrics import (confusion_matrix, ConfusionMatrixDisplay)

from data_loader import load_data

DATA_DIR = "../../data/task2_data"
X_paths, X_test_paths, y = load_data(DATA_DIR)

print("Number of training images:", len(X_paths))
print("Number of test images:", len(X_test_paths))

#image transformations for ResNet50
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),

    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
])

#pretrained ResNet50 feature extractor
#implemented using PyTorchs torchvision.models.resnet50 (https://docs.pytorch.org/vision/stable/index.html)
weights = models.ResNet50_Weights.DEFAULT
model = models.resnet50(weights=weights)

#remove final classification layer
feature_extractor = torch.nn.Sequential(*list(model.children())[:-1])
feature_extractor.eval()

#feature extraction function
def extract_features(image_paths):
    features = []

    with torch.no_grad():
        for path in tqdm(image_paths):
            full_path = f"{DATA_DIR}/{path}"
            img = Image.open(full_path).convert("RGB")
            img = transform(img).unsqueeze(0)
            feat = feature_extractor(img)
            feat = feat.squeeze().numpy()
            features.append(feat)
    return np.array(features)

#extrcat features for training and test sets
X = extract_features(X_paths)
X_test = extract_features(X_test_paths)

print("\nFeature shape:", X.shape)

#pca
pca = PCA(n_components=0.95)
X = pca.fit_transform(X)
X_test = pca.transform(X_test)
print("PCA feature shape:", X.shape)

#train-val split
X_train, X_val, y_train, y_val = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

#svm with tuning (GRID SEARCH)
svm_pipeline = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", SVC(
        kernel="rbf",
        probability=True,
        C=10,
        gamma="scale"
    ))
])

svm_pipeline.fit(X_train, y_train)
svm_preds = svm_pipeline.predict(X_val)
print("\nSVM accuracy:", accuracy_score(y_val, svm_preds))

#gradient boosting
gb_model = HistGradientBoostingClassifier(
    learning_rate=0.05,
    max_depth=6,
    max_iter=400,
    random_state=42
)

gb_model.fit(X_train, y_train)
gb_preds = gb_model.predict(X_val)
print("\nGradient boosting accuracy:", accuracy_score(y_val, gb_preds))

#ensemble model
ensemble = VotingClassifier(
    estimators=[
        ("svm", svm_pipeline),
        ("gb", gb_model)
    ],
    voting="soft",
    weights=[2, 3]
)

ensemble.fit(X_train, y_train)
ensemble_preds = ensemble.predict(X_val)
print("\nEnsemble accuracy:", accuracy_score(y_val, ensemble_preds))

#cross validation for ensemble
cross_val_score(ensemble, X, y, cv=5)

#confusion matrix for ensemble
cm = confusion_matrix(y_val, ensemble_preds)
disp = ConfusionMatrixDisplay(confusion_matrix=cm)
disp.plot()
plt.show()

#train final model on full datast
final_model = ensemble
final_model.fit(X, y)
test_preds = final_model.predict(X_test)

#kaggle
test_meta = pd.read_csv("../../data/task2_data/test_metadata.csv")
submission = pd.DataFrame({
    "image_id": test_meta["image_id"],
    "class_id": test_preds
})
submission.to_csv("submission_task2.csv", index=False)