import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import (train_test_split, GridSearchCV, cross_val_score)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectKBest, mutual_info_classif
from sklearn.metrics import (accuracy_score, confusion_matrix, ConfusionMatrixDisplay)

from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import (HistGradientBoostingClassifier, VotingClassifier)

from data_loader import load_data

X, X_test, y = load_data("../../data/task1_data")
X_train, X_val, y_train, y_val = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)
print("Train shape:", X_train.shape)

#logistic regression with feature selection
#from Week 8 tutorial
log_model = Pipeline([
    ("scaler", StandardScaler()),

    #feature selection using mutual information
    #from Week 8 tutorial
    ("select", SelectKBest(
        score_func=mutual_info_classif,
        k=150
    )),

    ("clf", LogisticRegression(
        max_iter=5000,
        C=2,
        solver="lbfgs"
    ))
])

log_model.fit(X_train, y_train)
log_preds = log_model.predict(X_val)

print("\nLogistic regression accuracy:",
      accuracy_score(y_val, log_preds))

#svm with tuning (GRID SEARCH)
#from Week 6 tutorial
svm_pipeline = Pipeline([
    ("scaler", StandardScaler()),

    ("clf", SVC(
        probability=True
    ))
])

#from Week 6 tutorial
svm_param_grid = {
    "clf__C": [1, 10, 50],
    "clf__gamma": ["scale", 0.001, 0.0001],
    "clf__kernel": ["rbf"]
}

svm_grid = GridSearchCV(
    svm_pipeline,
    svm_param_grid,
    cv=3,
    n_jobs=-1,
    verbose=1
)

svm_grid.fit(X_train, y_train)
svm_preds = svm_grid.predict(X_val)

print("\nSVM best parameters:", svm_grid.best_params_)
print("SVM accuracy:", accuracy_score(y_val, svm_preds))

#gradient boosting with tuning (GRID SEARCH)
gb_param_grid = {
    "learning_rate": [0.03, 0.05, 0.1],
    "max_depth": [4, 6, 8],
    "min_samples_leaf": [10, 20, 30],
    "max_iter": [300, 500],
    "l2_regularization": [0, 0.1]
}

gb_grid = GridSearchCV(
    HistGradientBoostingClassifier(random_state=42),
    gb_param_grid,
    cv=3,
    n_jobs=-1,
    verbose=1
)

gb_grid.fit(X_train, y_train)
gb_model = gb_grid.best_estimator_
gb_preds = gb_model.predict(X_val)

print("\nGradient boosting best parameters:", gb_grid.best_params_)
print("Gradient boosting accuracy:", accuracy_score(y_val, gb_preds))

#ensemble of best models
ensemble = VotingClassifier(
    estimators=[
        ("gb", gb_model),
        ("log", log_model),
        ("svm", svm_grid.best_estimator_)
    ],

    voting="soft",

    #stronger weight to best model
    weights=[4, 2, 1]
)

ensemble.fit(X_train, y_train)

ensemble_preds = ensemble.predict(X_val)

print("\nEnsemble accuracy:", accuracy_score(y_val, ensemble_preds))

#summary stats
print("Summary:")
print("Logistic regression:", accuracy_score(y_val, log_preds))
print("SVM:", accuracy_score(y_val, svm_preds))
print("Gradient boosting:", accuracy_score(y_val, gb_preds))
print("Ensemble:", accuracy_score(y_val, ensemble_preds))

cv_scores = cross_val_score(
    ensemble,
    X,
    y,
    cv=5,
    scoring="accuracy",
    n_jobs=-1
)

print("\nCross validation accuracy:", cv_scores.mean())
print("Fold scores:", cv_scores)

cm = confusion_matrix(y_val, ensemble_preds)
disp = ConfusionMatrixDisplay(confusion_matrix=cm)
disp.plot()
plt.show()

final_model = ensemble
final_model.fit(X, y)
test_preds = final_model.predict(X_test)

#kaggle
test_meta = pd.read_csv("../../data/task1_data/test_metadata.csv")

submission = pd.DataFrame({
    "image_id": test_meta["image_id"],
    "class_id": test_preds
})

submission.to_csv("submission_task1.csv", index=False)