#to install libraries: pip install pandas scikit-learn numpy matplotlib
#to run: cd code/task1
#        python train.py

import pandas as pd
import os

def load_data(base_path):
    train_meta = pd.read_csv(os.path.join(base_path, "train_metadata.csv"))
    test_meta = pd.read_csv(os.path.join(base_path, "test_metadata.csv"))

    colour = pd.read_csv(os.path.join(base_path, "color_histogram.csv"))
    hog = pd.read_csv(os.path.join(base_path, "hog_pca.csv"))
    extra = pd.read_csv(os.path.join(base_path, "additional_features.csv"))

    #combine features
    X = pd.concat([colour, hog, extra], axis=1)

    #keep only numeric
    X = X.select_dtypes(include=['number'])
    #fill missing values with mean
    X = X.fillna(X.mean())

    n_train = len(train_meta)

    X_train = X.iloc[:n_train].reset_index(drop=True)
    X_test = X.iloc[n_train:].reset_index(drop=True)

    y_train = train_meta["class_id"]
    return X_train, X_test, y_train